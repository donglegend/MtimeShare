var STYLES = {
    2: {
        bgColor: '0xebe2d8',
        fontColor: '#756d63'
    },
    4: {
        bgColor: '0Xeaddc6',
        fontColor: '#756d63'
    },
    8: {
        bgColor: '0Xefaf77',
        fontColor: '#f8f5f1'
    },
    16: {
        bgColor: '0Xf39463',
        fontColor: '#f8f5f1'
    },
    32: {
        bgColor: '0Xf37a5e',
        fontColor: '#f8f5f1'
    },
    64: {
        bgColor: '0Xf45d3a',
        fontColor: '#f8f5f0'
    },
    128: {
        bgColor: '0Xedcf72',
        fontColor: '#f8f5f0'
    },
    256: {
        bgColor: '0Xedcb5f',
        fontColor: '#f9f6f3'
    },
    512: {
        bgColor: '0Xedc850',
        fontColor: '#f8f5f1'
    },
    1024: {
        bgColor: '0Xedc53f',
        fontColor: '#f8f5f3'
    },
    2048: {
        bgColor: '0X3e3c31',
        fontColor: '#f8f5f0'
    },
    4096: {
        bgColor: '0X2b2a23',
        fontColor: '#f8f5f0'
    },
    8192: {
        bgColor: '0X21201b',
        fontColor: '#f8f5f0'
    }
}